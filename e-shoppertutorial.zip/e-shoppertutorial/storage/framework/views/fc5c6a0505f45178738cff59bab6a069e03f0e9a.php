<?php $__env->startSection("content"); ?>
<section id="cart_items">
<div class="container">
  <div class="breadcrumbs">
      <ol class="breadcrumb">
          <li><a href="/">Home</a></li>
          <li class="active">Shopping Cart</li>
      </ol>
  </div>
      <div class="shopper-informations">
          <div class="row">
              <div class="col-sm-12 clearfix">
                  <div class="bill-to">
                      <p> Shipping/Bill To</p>
                      <div class="form-one">
                          <form action="/products/createOrder" method="post" class="form-group">
                              <?php echo e(csrf_field()); ?>

                              <input type="text" name="email" placeholder="Email*" required>
                              <input type="text" name="fname" placeholder="First Name *" required>
                              <input type="text" name="lname" placeholder="Last Name *"  required>
                              <input type="text" name="address" placeholder="Address 1 *" required>
                              <input type="text" name="zip" placeholder="Zip / Postal Code *" required>
                              <input type="text" name="phone" placeholder="Phone *">
                              <button class="btn btn-default check_out" type="submit" name="submit" >Proceed To Payment</button>
                          </form>
                      </div>
                  </div>
              </div>
          </div>
      </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-shoppertutorial\resources\views/products/checkoutPage.blade.php ENDPATH**/ ?>