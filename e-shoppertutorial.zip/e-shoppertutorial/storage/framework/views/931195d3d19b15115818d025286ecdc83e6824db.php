<?php $__env->startSection('body'); ?>
<?php if($users->count()>0): ?>
<div class="table-responsive">
  <h2>Users Panel</h2>
  <table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Name</th>
        <th scope="col">Email</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($user->id); ?></th>
        <th scope="row"><?php echo e($user->name); ?></th>
        <th scope="row"><?php echo e($user->email); ?></th>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php echo e($users->links()); ?>

</div>
<?php else: ?>
    <div class="alert alert-danger my-2">
          <p>ไม่มีข้อมูลผู้ใช้ในระบบ</p>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-shoppertutorial\resources\views/admin/displayUser.blade.php ENDPATH**/ ?>