<?php $__env->startSection('body'); ?>
<?php if($orders->count()>0): ?>
<div class="table-responsive">
  <h2>Order Panel</h2>
  <table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">OrderID</th>
        <th scope="col">Date</th>
        <th scope="col">Delivery</th>
        <th scope="col">Price</th>
        <th scope="col">Status</th>
        <th scope="col">UserID</th>
        <th scope="col">Order Details</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($order->order_id); ?></th>
        <th scope="row"><?php echo e($order->date); ?></th>
        <th scope="row"><?php echo e($order->del_date); ?></th>
        <th scope="row"><?php echo e(number_format($order->price)); ?></th>
        <th scope="row">
          <span class="
              <?php if($order->status=='Not Paid'): ?>
                  badge badge-danger
              <?php else: ?>
                  badge badge-success
              <?php endif; ?>
          "><?php echo e($order->status); ?></span>
        </th>
        <th scope="row"><?php echo e($order->user_id); ?></th>
        <td>
            <a href="/admin/orders/detail/<?php echo e($order->order_id); ?>" class="btn btn-info">Detail</a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php echo e($orders->links()); ?>

</div>
<?php else: ?>
    <div class="alert alert-danger my-2">
          <p>ไม่มีข้อมูลใบสั่งซื้อสินค้าในระบบ</p>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-shoppertutorial\resources\views/admin/OrderPanel.blade.php ENDPATH**/ ?>