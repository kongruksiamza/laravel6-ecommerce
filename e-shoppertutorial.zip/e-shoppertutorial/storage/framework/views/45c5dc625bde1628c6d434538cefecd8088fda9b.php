<?php $__env->startSection('body'); ?>
<?php if($orderitems->count()>0): ?>
<div class="table-responsive">
  <h2>Order Details</h2>
  <table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">Item ID</th>
        <th scope="col">Item Name</th>
        <th scope="col">Item Price</th>
        <th scope="col">Item Amount</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $orderitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($orderitem->item_id); ?></th>
        <th scope="row"><?php echo e($orderitem->item_name); ?></th>
        <th scope="row"><?php echo e(number_format($orderitem->item_price,2)); ?></th>
        <th scope="row"><?php echo e(number_format($orderitem->item_amount,2)); ?></th>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <a href="/admin/orders" class="btn btn-primary">Back</a>
</div>
<?php else: ?>
    <div class="alert alert-danger my-2">
          <p>ไม่มีข้อมูลสินค้าในใบสั่งซื้อ</p>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-shoppertutorial\resources\views/admin/orderDetails.blade.php ENDPATH**/ ?>