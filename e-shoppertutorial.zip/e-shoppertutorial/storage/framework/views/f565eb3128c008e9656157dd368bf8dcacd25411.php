<?php $__env->startSection('body'); ?>
<?php if($products->count()>0): ?>
<div class="table-responsive">
  <h2>Product Dashboard</h2>
  <table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Image</th>
        <th scope="col">Name</th>
        <th scope="col">Description</th>
        <th scope="col">Category</th>
        <th scope="col">Price</th>
        <th scope="col">Edit Image</th>
        <th scope="col">Edit</th>
        <th scope="col">Remove</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($product->id); ?></th>
        <td>
            <img src="<?php echo e(asset('storage')); ?>/product_image/<?php echo e($product->image); ?>" alt="" width="100px" height="100px">
        </td>
        <td><?php echo e($product->name); ?></td>
        <td><?php echo e(Str::limit($product->description,30)); ?></td>
        <td>
            <?php echo e($product->category->name); ?>

        </td>
        <td><?php echo e(number_format($product->price)); ?></td>
        <td>
            <a href="/admin/editProductImage/<?php echo e($product->id); ?>" class="btn btn-success">Edit Image</a>
        </td>
        <td>
            <a href="/admin/editProduct/<?php echo e($product->id); ?>" class="btn btn-primary">Edit</a>
        </td>
        <td>
            <a href="/admin/deleteProduct/<?php echo e($product->id); ?>" onclick="return confirm('คุณต้องการลบข้อมูลหรือไม่ ?')" class="btn btn-danger">Remove</a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php echo e($products->links()); ?>

</div>
<?php else: ?>
    <div class="alert alert-danger my-2">
          <p>ไม่มีข้อมูลสินค้า</p>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-shoppertutorial\resources\views/admin/ProductDashboard.blade.php ENDPATH**/ ?>