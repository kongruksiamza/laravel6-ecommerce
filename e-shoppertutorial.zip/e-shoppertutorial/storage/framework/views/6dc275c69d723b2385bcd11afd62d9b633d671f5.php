<?php $__env->startSection('body'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="table-responsive">
    <h2>Current Image</h2>
    <div>
          <img src="<?php echo e(asset('storage')); ?>/product_image/<?php echo e($product->image); ?>" alt="" width="150px" height="150px">
    </div>
    <form action="/admin/updateProductImage/<?php echo e($product->id); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="image">Image</label>
            <input type="file" class="form-control"  name="image" id="image">
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Update Image</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-shoppertutorial\resources\views/admin/editProductImage.blade.php ENDPATH**/ ?>