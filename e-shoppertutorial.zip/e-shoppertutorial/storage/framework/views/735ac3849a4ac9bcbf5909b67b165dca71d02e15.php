<?php $__env->startSection('body'); ?>
<?php if($payments->count()>0): ?>
<div class="table-responsive">
  <h2>Payments Panel</h2>
  <table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Date</th>
        <th scope="col">Paypal OrderID</th>
        <th scope="col">Paypal PayerID</th>
        <th scope="col">Amount</th>
        <th scope="col">Order ID</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($payment->id); ?></th>
        <th scope="row"><?php echo e($payment->date); ?></th>
        <th scope="row"><?php echo e($payment->paypal_order_id); ?></th>
        <th scope="row"><?php echo e($payment->payer_id); ?></th>
        <th scope="row"><?php echo e(number_format($payment->amount)); ?></th>
        <th scope="row"><?php echo e($payment->order_id); ?></th>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php echo e($payments->links()); ?>

</div>
<?php else: ?>
    <div class="alert alert-danger my-2">
          <p>ไม่มีข้อมูลการชำระเงินในระบบ</p>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-shoppertutorial\resources\views/admin/paymentsPanel.blade.php ENDPATH**/ ?>