<?php $__env->startSection("content"); ?>
<section id="cart_items">
<div class="container">
<div class="breadcrumbs">
  <ol class="breadcrumb">
    <li><a href="/products">Home</a></li>
    <li class="active">Shopping Cart</li>
  </ol>
</div>
<?php if(Session()->has('warning')): ?>
    <div class="alert alert-danger" role="alert">
          <?php echo e(Session()->get('warning')); ?>

    </div>
<?php endif; ?>
<div class="table-responsive cart_info">
  <table class="table table-condensed">
    <thead>
      <tr class="cart_menu">
        <td class="image">Item</td>
        <td class="description">Description</td>
        <td class="price">Price</td>
        <td class="quantity">Quantity</td>
        <td class="total">Total</td>
        <td></td>
      </tr>
    </thead>
    <tbody>
          <?php $__currentLoopData = $cartItems->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="cart_product">
              <a href="/products/details/<?php echo e($item['data']['id']); ?>"><img src="<?php echo e(asset('storage')); ?>/product_image/<?php echo e($item['data']['image']); ?>" alt="" width="70px" height="70px"></a>
            </td>
            <td class="cart_description">
              <h4><a href="/products/details/<?php echo e($item['data']['id']); ?>"><?php echo e($item['data']['name']); ?></a></h4>
              <p><?php echo e(Str::limit($item['data']['description'],50)); ?></p>
            </td>
            <td class="cart_price">
              <p><?php echo e(number_format($item['data']['price'],2)); ?></p>
            </td>
            <td class="cart_quantity">
              <div class="cart_quantity_button">
                <a class="cart_quantity_up" href="/products/cart/incrementCart/<?php echo e($item['data']['id']); ?>"> + </a>
                <input class="cart_quantity_input" type="text" name="quantity" value="<?php echo e($item['quantity']); ?>" autocomplete="off" size="2">
                <a class="cart_quantity_down" href="/products/cart/decrementCart/<?php echo e($item['data']['id']); ?>"> - </a>
              </div>
            </td>
            <td class="cart_total">
              <p class="cart_total_price"><?php echo e(number_format($item['totalSinglePrice'])); ?></p>
            </td>
            <td class="cart_delete">
              <a class="cart_quantity_delete" onclick="return confirm('คุณต้องการลบสินค้าหรือไม่ ?')" href="/products/cart/deleteFromCart/<?php echo e($item['data']['id']); ?>"><i class="fa fa-times"></i></a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
</div>
</section> <!--/#cart_items-->

<section id="do_action">
<div class="container">
<div class="row">
  <div class="col-sm-12">
    <div class="total_area">
      <ul>
        <li>จำนวนสินค้า<span><?php echo e($cartItems->totalQuantity); ?></span></li>
        <li>ราคารวม<span><?php echo e(number_format($cartItems->totalPrice)); ?></span></li>
      </ul>
        <a class="btn btn-default update" href="">Update</a>
        <a class="btn btn-default check_out" href="/products/checkout">Check Out</a>
    </div>
  </div>
</div>
</div>
</section><!--/#do_action-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-shoppertutorial\resources\views/products/showCart.blade.php ENDPATH**/ ?>