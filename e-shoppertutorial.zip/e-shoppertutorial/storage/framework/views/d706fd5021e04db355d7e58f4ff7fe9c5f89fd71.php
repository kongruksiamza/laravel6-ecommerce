<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">My Profile</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <p><strong>Name :</strong><?php echo Auth::user()->name; ?></p>
                    <p><strong>Email :</strong><?php echo Auth::user()->email; ?></p>
                    <?php if(Auth::user()->checkIsAdmin()): ?>
                          <a href="/admin/dashboard" class="btn btn-primary">Product Management</a>
                    <?php endif; ?>
                    <a href="/products" class="btn btn-success">Home</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-shoppertutorial\resources\views/home.blade.php ENDPATH**/ ?>