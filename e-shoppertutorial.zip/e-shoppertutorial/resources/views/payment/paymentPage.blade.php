@extends("layouts.index")
@section("content")
<section id="cart_items">
<div class="container">
<div class="breadcrumbs">
<ol class="breadcrumb">
    <li><a href="/">Home</a></li>
    <li class="active">Shopping Cart</li>
</ol>
</div>
<div class="shopper-informations">
    <div class="row">
        <div class="col-sm-12 clearfix">
            <div class="bill-to">
                <p> Shipping/Bill To</p>
                <div class="form-one">
                        <div class="total_area" style="padding:10px">
                            <ul>
                              <li>Payment Status
                                  @if($payment_info['status']== 'Not Paid')
                                      <span>ยังไม่ชำระเงิน</span>
                                  @endif
                              </li>
                              <li>Total
                                    <span>{{number_format($payment_info['price'])}}</span>
                              </li>
                              <li>
                                    <div id="paypal-button-container"></div>
                              </li>
                            </ul>

                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</section>
<script
    src="https://www.paypal.com/sdk/js?client-id=ARK89CDQ2NSfmaI9fQHtzMkvYF5UkWmdSwTl8ycLEkbMib-JIgR0swcNMnT-OumslFydHfeEo3MwER7V"> // Required. Replace SB_CLIENT_ID with your sandbox client ID.
</script>
<script>
  paypal.Buttons({
    createOrder: function(data, actions) {
      return actions.order.create({
        purchase_units: [{
          amount: {
            value: '{{$payment_info['price']}}'
          }
        }]
      });
    },
    onApprove: function(data, actions) {
      return actions.order.capture().then(function(details) {
            window.location='/paymentreceipt/'+data.orderID+'/'+data.payerID;
      });
    }
  }).render('#paypal-button-container');
</script>
@endsection
